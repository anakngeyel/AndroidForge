# StokToko Android v3

Aplikasi pengelolaan stok toko offline berbasis WebView.

## Fitur
- Master barang dengan SKU, nama, stok, harga beli/jual, dan stok minimum.
- Transaksi penjualan multi-SKU: cari SKU/nama dari master barang, masukkan jumlah dan harga, tambah banyak baris ke keranjang, validasi stok, lalu simpan satu transaksi.
- Barang masuk/keluar.
- Laporan omzet dan estimasi laba yang menghitung seluruh item transaksi multi-SKU serta transaksi penjualan v2 lama.
- Klasifikasi fast/slow/dead 30 hari.
- Data lokal di WebView LocalStorage.
- Backup JSON melalui pemilih dokumen Android (ACTION_CREATE_DOCUMENT), sehingga pengguna memilih folder/lokasi dan nama file sebelum penyimpanan.
- Pemulihan backup JSON melalui pemilih file HTML.

## Catatan data
Sebelum memperbarui APK, buat backup JSON dan simpan di lokasi yang mudah ditemukan. Pembaruan APK umumnya mempertahankan LocalStorage jika applicationId dan signing key sama; jangan mengandalkan hal itu sebagai satu-satunya salinan.
