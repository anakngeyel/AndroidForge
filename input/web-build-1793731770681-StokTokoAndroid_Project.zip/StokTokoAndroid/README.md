# StokToko Android — project APK

Project Android Studio yang membungkus aplikasi StokToko v2 sebagai aplikasi Android offline menggunakan WebView lokal. Tidak membutuhkan permission internet.

## Membuat APK
1. Instal Android Studio di komputer.
2. Buka folder `StokTokoAndroid` melalui **Open**.
3. Tunggu Gradle sync selesai (Android Studio akan mengunduh Android Gradle Plugin/SDK yang dibutuhkan).
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug akan dibuat di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan data
- Data aplikasi disimpan di localStorage WebView pada perangkat.
- Jangan uninstall aplikasi atau menghapus data aplikasi sebelum membuat backup dari menu Cadangkan data.
- APK ini offline; tidak ada izin INTERNET di AndroidManifest.
- Untuk distribusi luas, buat APK release yang ditandatangani melalui Build > Generate Signed Bundle / APK.
